---
layout: page2
title: Nicolas Magain - About 
description: When building a website it's helpful to see what the focus of your site is. This page is an example of how to show a website's focus.
sitemap:
    priority: 0.7
    lastmod: 2017-11-02
    changefreq: weekly
---
## Friends


<p> The website of the great phycologist <a href="https://eterlova.weebly.com/"> Elizaveta Terlova</a>
<br /> The very impressive page of <a href="https://kohsuanchen.wixsite.com/fungi">Chen Ko Hsuan's</a> lab.
<br /> The website of the cool lichenologist <a href="https://imedeirosbotany.wordpress.com/"> Ian Medeiros</a>
<br /> The page of the nice <a href="http://lutzonilab.org/"> Lutzoni lab</a> website. </p>

  <p>
 In development </p>
</div>
