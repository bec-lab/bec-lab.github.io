---
layout: page2
title: Nicolas Magain - About 
description: When building a website it's helpful to see what the focus of your site is. This page is an example of how to show a website's focus.
sitemap:
    priority: 0.7
    lastmod: 2017-11-02
    changefreq: weekly
---
## Team


<p> In development
### My work
<div class="box">
  <p>
 In development </p>
</div>
