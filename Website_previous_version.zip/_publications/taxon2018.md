---
short_title: Taxon2018
title: Species delimitation at a global scale reveals high species richness with complex biogeography and patterns of symbiont association in Peltigera section Peltigera (lichenized Ascomycota, Lecanoromycetes).
authors: Magain, N., Truong, C., Goward, T., Niu, D., Goffinet, B., Sérusiaux, E., Lutzoni, F. & Miadlikowska, J. 
year: 2018
journalinfo: Taxon, 67(5), 836-870.
pdf: "/PDF/MagainTaxon2018.pdf"
orbi: https://orbi.uliege.be/handle/2268/228263
journal: "https://academic.oup.com/sysbio/article/66/1/74/2670079"
---
