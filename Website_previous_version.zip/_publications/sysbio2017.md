---
short_title: Sysbio2017
title: Macroevolution of Specificity in Cyanolichens of the Genus Peltigera Section Polydactylon (Lecanoromycetes, Ascomycota)
authors: Magain, N., Miadlikowska, J., Goffinet, B., Sérusiaux, E., & Lutzoni, F. 
year: 2017
pdf: "/PDF/MagainSysBio2017.pdf"
orbi: "https://orbi.uliege.be/handle/2268/206955"
journal: "https://academic.oup.com/sysbio/article/66/1/74/2670079"
---
